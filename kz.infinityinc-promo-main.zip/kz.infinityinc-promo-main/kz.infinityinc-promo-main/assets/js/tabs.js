$(document).ready(function () {
  $('.tabbed-nav').accordionortabs({
    defaultOpened: 0,
    containerBreakPoint: 0, 
    tabsIfPossible: true,
    hashbangPrefix: 'tabset_',
    centerTabs: false
  });
});




